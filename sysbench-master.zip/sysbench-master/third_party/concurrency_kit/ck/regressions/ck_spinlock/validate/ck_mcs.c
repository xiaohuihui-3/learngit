#include "../ck_mcs.h"
#include "validate.h"

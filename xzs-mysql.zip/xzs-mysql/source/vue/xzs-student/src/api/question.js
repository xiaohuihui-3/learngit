import { post } from '@/utils/request'

export default {
}

module.exports = {
  appKey: '9abd2dfe51',
  hasPlugin: false,
  getLocation: false
};
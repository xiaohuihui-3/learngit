Component({
    externalClasses: ['i-class'],

    relations: {
        '../col/index': {
            type: 'child'
        }
    }
});
